<?php
// Identifiants de ta base de données gratuite en ligne (Aiven)
$host = "mysql-3a089ff2-arounatraore592-6bf5.e.aivencloud.com";
$port = "16042";
$user = "avnadmin";
$pass = "AVNS_pOWHh7anA31D-8JznZT";
$dbname = "defaultdb";

try {
    // Connexion PDO sécurisée avec le port d'Aiven et l'option SSL obligatoire
    $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8";
    $options = [
        PDO::MYSQL_ATTR_SSL_CA => true, // <-- C'est cette ligne qui active le SSL requis par Aiven
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ];

    $pdo = new PDO($dsn, $user, $pass, $options);

    // Activation des alertes d'erreurs SQL pour le développement
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Liaison indispensable pour que toutes tes pages fonctionnent
    $bdd = $pdo;
    $conn = $pdo;

} catch (PDOException $e) {
    die("Erreur de connexion à la base en ligne : " . $e->getMessage());
}
?>
?>